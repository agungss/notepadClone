# notepadClone
Notepad clone. I made this to use notepad in my mac. Also I like coding C in notepad, clean, without any noise/syntax highlighting

##Screenshots

<img src="images/screenshot1.png" width="500">
<img src="images/screenshot2.png" width="500">